# profile-page
An example profile page made for an LHS WebDev meeting.  
Check it out [here]( https://lhswebdev.github.io/profile-page/ ).  
